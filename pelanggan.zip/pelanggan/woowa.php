<?php  
/** 
* Plugin Name: Whatsapp Notification
* Plugin URI: https://pelanggan.net 
* Description: Woocommerce Whatsapp Notifier
* Version: 0.1.1-beta
* Author: PELANGGAN.NET
* Author URI: https://pelanggan.net
* License: GPL-2.0+   
* License URI: http://www.gnu.org/licenses/gpl-2.0.txt 
*/ 
require_once 'libs.php';