<?php

define('MY_VERIFICATION_KEY', '5bcef68261e3f5.98451014' ); 
define('MY_HOST_SERVER'		, 'http://my.woo-wa.com'); 
define('SENDINGWHA_URL'		, 'http://sendingwha.woo-wa.com/v1.0/index.php');
define('CEK_UPDATE_PREMIUM'	, 'http://sendingwha.woo-wa.com/v1.0/index.php?go=cek-update-premium');
define('GET_UPDATE'			, 'http://sendingwha.woo-wa.com/v1.0/modules/premium/update/woowap');
define('CEK_EXPIRED'		, 'http://bumi.enalab.com:12770/api/cek/access_key');
define('STATISTIC'			, 'http://sendingwha.woo-wa.com/v1.0/index.php?go=get-count-sent-wa-premium&');
define('OS_URL'			, "https://onesignal.com/api/v1/notifications");
define('GET_DATACS', "http://api.woo-wa.com/v2.0/woowandroid/get-cs-id/");
define('OS_APP_ID', "429d3472-da0f-4b2b-a63e-4644050caf8f");
define('OS_AUTH',"NjY0NzE3MTYtMzc3ZC00YmY5LWJhNzQtOGRiMWM1ZTNhNzBh");

// define('OS_APP_ID'			, "5d57c663-3eef-4098-93ab-8912cd93a60b");
// define('OS_AUTH'			, "MzEyNjk1YmMtYmJmYS00YTYxLWEyNzctZDcxMDEzMDZlMjgx");