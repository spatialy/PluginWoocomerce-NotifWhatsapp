<?php

class MainOrderCompleted{
    public function save(){
        
    }

    public function follow_up_order(){
        
    }
}