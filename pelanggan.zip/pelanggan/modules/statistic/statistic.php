<?php 

woowa_hook_wpajax("quota_harian_chart");
woowa_hook_wpajax("quota_harian_table");

?>